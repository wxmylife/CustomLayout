package com.xueersi.parentsmeeting.module.fusionlogin.widget.phoneinput;

import android.content.Context;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.sensorsdata.analytics.android.sdk.SensorsDataAutoTrackHelper;
import com.sensorsdata.analytics.android.sdk.SensorsDataInstrumented;
import com.xueersi.lib.framework.utils.SizeUtils;
import com.xueersi.parentsmeeting.module.fusionlogin.R;

public class PhoneInputEdit extends LinearLayout implements View.OnClickListener {
    public static final String CN = "CN";
    public static final String HK = "HK";
    public static final String MO = "MO";
    public static final String TW = "TW";
    /* access modifiers changed from: private */
    public boolean editHasFocus;
    /* access modifiers changed from: private */
    public boolean isChange;
    private boolean isShowPop;
    private boolean isValid;
    private Context mContext;
    public String mCurrentCode;
    private ImageView mDeleteView;
    /* access modifiers changed from: private */
    public EditText mEditText;
    /* access modifiers changed from: private */
    public EtFocusChangeCallback mEtFocusChange;
    /* access modifiers changed from: private */
    public PhoneInputFilter mInputFilter;
    private View mPopuContentView;
    /* access modifiers changed from: private */
    public PopuShowCallback mPopuShowCallback;
    /* access modifiers changed from: private */
    public PopupWindow mPopuWindow;
    private TextView mSpinnerTv;
    private PhoneInputValidCallback mValidCallback;
    private View vCN;
    private View vHK;
    private View vMO;
    private View vTW;

    public interface EtFocusChangeCallback {
        void onFocusChange(boolean z);
    }

    public interface PhoneInputValidCallback {
        void onValid(boolean z);
    }

    public interface PopuShowCallback {
        void onShow(boolean z);
    }

    public PhoneInputEdit(Context context) {
        this(context, (AttributeSet) null);
    }

    public PhoneInputEdit(Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PhoneInputEdit(Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mCurrentCode = "CN";
        this.isChange = true;
        this.isValid = false;
        this.isShowPop = true;
        this.editHasFocus = false;
        this.mContext = context;
        LayoutInflater.from(context).inflate(R.layout.layout_phone_input, this, true);
        init();
        initViews();
        setDeleteShow(!TextUtils.isEmpty(this.mEditText.getText().toString()));
    }

    private void init() {
        if (this.mInputFilter == null) {
            this.mInputFilter = new CNinputFilter();
        }
    }

    /* access modifiers changed from: private */
    public void setTextNoChange(String str) {
        this.isChange = false;
        this.mEditText.setText(str);
        this.mEditText.setSelection(str.length());
        if (this.mValidCallback != null) {
            this.mValidCallback.onValid(this.mInputFilter.isValid(str));
        }
        this.isChange = true;
    }

    /* access modifiers changed from: private */
    public void setTextWitchDelete(String str, int i) {
        this.isChange = false;
        int selectionStart = this.mEditText.getSelectionStart();
        this.mEditText.setText(str);
        int i2 = selectionStart - i;
        if (i2 >= 0) {
            this.mEditText.setSelection(i2);
        } else {
            this.mEditText.setSelection(0);
        }
        if (this.mValidCallback != null) {
            this.mValidCallback.onValid(this.mInputFilter.isValid(str));
        }
        this.isChange = true;
    }

    /* access modifiers changed from: private */
    public void showPopu(boolean z) {
        if (this.isShowPop) {
            if (z) {
                if (this.mPopuWindow == null) {
                    this.mPopuContentView = LayoutInflater.from(this.mContext).inflate(R.layout.layout_phone_cuntry_pop, (ViewGroup) null);
                    this.mPopuContentView.findViewById(R.id.pop_country_1).setOnClickListener(this);
                    this.mPopuContentView.findViewById(R.id.pop_country_2).setOnClickListener(this);
                    this.mPopuContentView.findViewById(R.id.pop_country_3).setOnClickListener(this);
                    this.mPopuContentView.findViewById(R.id.pop_country_4).setOnClickListener(this);
                    this.mPopuWindow = new PopupWindow(this.mPopuContentView, -2, -2, true);
                    this.mPopuWindow.setOutsideTouchable(true);
                    this.mPopuWindow.setTouchable(true);
                }
                this.mPopuWindow.showAsDropDown(this, -SizeUtils.Dp2Px(this.mContext, 8.0f), -SizeUtils.Dp2Px(this.mContext, 4.0f));
                return;
            }
            this.mPopuWindow.dismiss();
        }
    }

    public void setDeleteShow(boolean z) {
        this.mDeleteView.setVisibility((!z || !this.editHasFocus) ? 8 : 0);
    }

    public void setIsShowPop(boolean z) {
        this.isShowPop = z;
    }

    public void setCountriesCode(String str) {
        if (!TextUtils.isEmpty(str)) {
            this.mCurrentCode = str;
            if ("HK".equals(str)) {
                this.mSpinnerTv.setText("+852");
                this.mInputFilter = new HKinputFIlter();
            } else if ("TW".equals(str)) {
                this.mSpinnerTv.setText("+886");
                this.mInputFilter = new TWinputFilter();
            } else if ("MO".equals(str)) {
                this.mSpinnerTv.setText("+853");
                this.mInputFilter = new MOinputFIlter();
            } else {
                this.mSpinnerTv.setText("+86");
                this.mInputFilter = new CNinputFilter();
            }
            this.mEditText.setText(this.mEditText.getText());
        }
    }

    private void initViews() {
        this.mEditText = (EditText) findViewById(R.id.phone_input_edit_text);
        this.mDeleteView = (ImageView) findViewById(R.id.phone_input_delete);
        this.mSpinnerTv = (TextView) findViewById(R.id.phone_input_spinner);
        this.mSpinnerTv.setOnClickListener(new View.OnClickListener() {
            @SensorsDataInstrumented
            public void onClick(View view) {
                if (PhoneInputEdit.this.mPopuWindow == null || !PhoneInputEdit.this.mPopuWindow.isShowing()) {
                    if (PhoneInputEdit.this.mPopuShowCallback != null) {
                        PhoneInputEdit.this.mPopuShowCallback.onShow(true);
                    }
                    PhoneInputEdit.this.showPopu(true);
                } else {
                    if (PhoneInputEdit.this.mPopuShowCallback != null) {
                        PhoneInputEdit.this.mPopuShowCallback.onShow(false);
                    }
                    PhoneInputEdit.this.showPopu(false);
                }
                SensorsDataAutoTrackHelper.trackViewOnClick(view);
            }
        });
        findViewById(R.id.phone_input_spinner_arrow).setOnClickListener(new View.OnClickListener() {
            @SensorsDataInstrumented
            public void onClick(View view) {
                if (PhoneInputEdit.this.mPopuWindow == null || !PhoneInputEdit.this.mPopuWindow.isShowing()) {
                    if (PhoneInputEdit.this.mPopuShowCallback != null) {
                        PhoneInputEdit.this.mPopuShowCallback.onShow(true);
                    }
                    PhoneInputEdit.this.showPopu(true);
                } else {
                    if (PhoneInputEdit.this.mPopuShowCallback != null) {
                        PhoneInputEdit.this.mPopuShowCallback.onShow(false);
                    }
                    PhoneInputEdit.this.showPopu(false);
                }
                SensorsDataAutoTrackHelper.trackViewOnClick(view);
            }
        });
        this.mDeleteView.setOnClickListener(new View.OnClickListener() {
            @SensorsDataInstrumented
            public void onClick(View view) {
                PhoneInputEdit.this.setTextNoChange("");
                SensorsDataAutoTrackHelper.trackViewOnClick(view);
            }
        });
        this.mEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View view, boolean z) {
                if (PhoneInputEdit.this.mEtFocusChange != null) {
                    PhoneInputEdit.this.mEtFocusChange.onFocusChange(z);
                }
                boolean unused = PhoneInputEdit.this.editHasFocus = z;
                PhoneInputEdit.this.setDeleteShow(!TextUtils.isEmpty(PhoneInputEdit.this.mEditText.getText().toString()));
            }
        });
        this.mEditText.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (PhoneInputEdit.this.isChange) {
                    String charSequence2 = charSequence.toString();
                    if (TextUtils.isEmpty(charSequence2)) {
                        return;
                    }
                    if (i3 != 0) {
                        PhoneInputEdit.this.setTextNoChange(PhoneInputEdit.this.mInputFilter.onFilter(charSequence2));
                    } else if (' ' == charSequence2.charAt(charSequence2.length() - 1)) {
                        PhoneInputEdit.this.textsetTextWitchDelete(PhoneInputEdit.this.mInputFilter.onFilter(charSequence2.substring(0, charSequence2.length() - 1)), 1);
                    } else {
                        PhoneInputEdit.this.setTextWitchDelete(PhoneInputEdit.this.mInputFilter.onFilter(charSequence2), 0);
                    }
                } else {
                    PhoneInputEdit.this.setDeleteShow(!TextUtils.isEmpty(charSequence.toString()));
                }
            }

            public void afterTextChanged(Editable editable) {
                PhoneInputEdit.this.setDeleteShow(!TextUtils.isEmpty(editable.toString()));
            }
        });
    }

    @SensorsDataInstrumented
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.pop_country_1) {
            if (this.mPopuWindow != null) {
                this.mPopuWindow.dismiss();
            }
            setCountriesCode("CN");
        } else if (id == R.id.pop_country_2) {
            if (this.mPopuWindow != null) {
                this.mPopuWindow.dismiss();
            }
            setCountriesCode("HK");
        } else if (id == R.id.pop_country_3) {
            if (this.mPopuWindow != null) {
                this.mPopuWindow.dismiss();
            }
            setCountriesCode("MO");
        } else if (id == R.id.pop_country_4) {
            if (this.mPopuWindow != null) {
                this.mPopuWindow.dismiss();
            }
            setCountriesCode("TW");
        }
        SensorsDataAutoTrackHelper.trackViewOnClick(view);
    }

    public void setValidCallback(PhoneInputValidCallback phoneInputValidCallback) {
        this.mValidCallback = phoneInputValidCallback;
    }

    public void setPopuShowCallback(PopuShowCallback popuShowCallback) {
        this.mPopuShowCallback = popuShowCallback;
    }

    public void setEtFocusChangeCallback(EtFocusChangeCallback etFocusChangeCallback) {
        this.mEtFocusChange = etFocusChangeCallback;
    }

    public String getPhoneNumber() {
        Editable text = this.mEditText.getText();
        if (text == null) {
            return "";
        }
        char[] charArray = text.toString().toCharArray();
        StringBuilder sb = new StringBuilder();
        for (char c : charArray) {
            if (' ' != c) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public String getPhonePrefix() {
        return this.mInputFilter.getPhonePrefix();
    }

    public String getPhoneCode() {
        return this.mCurrentCode;
    }

    public void setPhoneNumber(String str) {
        setTextNoChange(this.mInputFilter.onFilter(str));
    }

    public boolean isValid() {
        return this.mInputFilter.isValid();
    }
}
