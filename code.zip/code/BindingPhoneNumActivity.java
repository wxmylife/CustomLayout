package com.xueersi.parentsmeeting.module.fusionlogin.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.sensorsdata.analytics.android.sdk.SensorsDataAutoTrackHelper;
import com.sensorsdata.analytics.android.sdk.SensorsDataInstrumented;
import com.tal.user.fusion.entity.TalAccErrorMsg;
import com.tal.user.fusion.entity.TalAccReq;
import com.tal.user.fusion.entity.TalAccResp;
import com.tal.user.fusion.http.TalAccApiCallBack;
import com.tal.user.fusion.manager.ITalAccRequestApi;
import com.tal.user.fusion.manager.TalAccApiFactory;
import com.xrs.bury.xrsbury.XrsBury;
import com.xueersi.common.base.BaseActivity;
import com.xueersi.common.business.LoginRegistersConfig;
import com.xueersi.common.business.UserBll;
import com.xueersi.common.config.AppConfig;
import com.xueersi.common.entity.UserInfoEdit;
import com.xueersi.lib.framework.utils.XESToastUtils;
import com.xueersi.parentsmeeting.module.fusionlogin.R;
import com.xueersi.parentsmeeting.module.fusionlogin.business.LoginProcessBll;
import com.xueersi.parentsmeeting.module.fusionlogin.business.LoginProcessController;
import com.xueersi.parentsmeeting.module.fusionlogin.callback.LoginProcessCallback;
import com.xueersi.parentsmeeting.module.fusionlogin.callback.RespTagCallback;
import com.xueersi.parentsmeeting.module.fusionlogin.dialog.SharedAccountDialog;
import com.xueersi.parentsmeeting.module.fusionlogin.entity.LoginAccountShareEntity;
import com.xueersi.parentsmeeting.module.fusionlogin.entity.ProcessEntity;
import com.xueersi.parentsmeeting.module.fusionlogin.utils.InputMethodUtil;
import com.xueersi.parentsmeeting.module.fusionlogin.utils.TalAccApiMethods;
import com.xueersi.parentsmeeting.module.fusionlogin.widget.AuthCodeLayout;
import com.xueersi.parentsmeeting.module.fusionlogin.widget.IntentUtils;
import com.xueersi.parentsmeeting.module.fusionlogin.widget.LogInTextView;
import com.xueersi.parentsmeeting.module.fusionlogin.widget.LoginTitleBar;
import com.xueersi.parentsmeeting.module.fusionlogin.widget.phoneinput.PhoneInputEdit;
import com.xueersi.ui.dataload.DataLoadEntity;
import org.greenrobot.eventbus.EventBus;

@Route(path = "/fusionlogin/setphonenumber")
public class BindingPhoneNumActivity extends LoginBaseActivity implements View.OnClickListener, PhoneInputEdit.PhoneInputValidCallback, AuthCodeLayout.AuthCodeViewStateListener {
    /* access modifiers changed from: private */
    public AuthCodeLayout authCodeLayout;
    /* access modifiers changed from: private */
    public DataLoadEntity dataLoadEntity;
    /* access modifiers changed from: private */
    public int from;
    private boolean isLastPage;
    private LoginTitleBar ltbTitle;
    private LogInTextView ltvBtn;
    private String mShowInfo;
    private String oldTag;
    /* access modifiers changed from: private */
    public PhoneInputEdit phoneInputEdit;
    private boolean phoneIsValid;
    private ITalAccRequestApi talAccRequestApi;
    private TextView tvBindingPhoneText;
    private boolean verifyCode;

    public static void openBindingPhoneNumActivity(Context context, String str, int i) {
        Intent intent = new Intent(context, BindingPhoneNumActivity.class);
        intent.putExtra("from", i);
        intent.putExtra("oldTag", str);
        context.startActivity(intent);
    }

    public static void openBindingPhoneNumActivityForResult(Activity activity, String str, int i) {
        Intent intent = new Intent(activity, BindingPhoneNumActivity.class);
        intent.putExtra("from", i);
        intent.putExtra("oldTag", str);
        activity.startActivityForResult(intent, LoginRegistersConfig.FUSION_REQUEST_CODE);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_binding_phone_num);
        EventBus.getDefault().register(this);
        this.dataLoadEntity = new DataLoadEntity(this.mContext);
        this.talAccRequestApi = TalAccApiFactory.getTalAccRequestApi();
        getIntents();
        initViews();
        setBtnEnable();
    }

    public void onResume() {
        super.onResume();
        if (this.from == 1) {
            XrsBury.pageStartBury(this.mContext.getResources().getString(R.string.fusionlogin_pv_084));
        }
    }

    public void onPause() {
        super.onPause();
        if (this.from == 1) {
            XrsBury.pageEndBury(this.mContext.getResources().getString(R.string.fusionlogin_pv_084));
        }
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1048867 && intent != null) {
            finish();
        }
    }

    private void getIntents() {
        Intent intent = getIntent();
        if (intent != null) {
            this.isLastPage = intent.getBooleanExtra("isLastPage", false);
            this.from = intent.getIntExtra("from", 1);
            this.oldTag = intent.getStringExtra("oldTag");
        }
        ProcessEntity processEntity = LoginProcessController.getInstance().getmProcessEntity();
        if (processEntity != null) {
            this.mShowInfo = processEntity.showInfo;
        }
    }

    private void initViews() {
        this.ltbTitle = findViewById(R.id.ltb_binding_phone_title);
        this.ltbTitle.setLoginTitle(getString(R.string.text_binding_phone_num));
        this.tvBindingPhoneText = (TextView) findViewById(R.id.tv_binding_phone_text);
        this.phoneInputEdit = findViewById(R.id.pie_binding_phone_num);
        this.phoneInputEdit.setValidCallback(this);
        this.phoneInputEdit.setPopuShowCallback(new PhoneInputEdit.PopuShowCallback() {
            /* JADX WARNING: type inference failed for: r1v1, types: [com.xueersi.parentsmeeting.module.fusionlogin.activity.BindingPhoneNumActivity, android.app.Activity] */
            public void onShow(boolean z) {
                if (z) {
                    InputMethodUtil.hideKeyboard(BindingPhoneNumActivity.this);
                }
            }
        });
        this.authCodeLayout = findViewById(R.id.acl_binding_phone_code);
        this.authCodeLayout.setAuthCodeViewListener(this);
        this.ltvBtn = findViewById(R.id.tv_binding_phone_num_btn);
        this.ltvBtn.setOnClickListener(this);
        View findViewById = findViewById(R.id.ll_verify_customer_service);
        SpannableString spannableString = new SpannableString(getString(R.string.text_no_update_help));
        spannableString.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.COLOR_212831)), spannableString.length() - 4, spannableString.length(), 33);
        ((TextView) findViewById(R.id.tv_update_help_center)).setText(spannableString);
        findViewById.setOnClickListener(new View.OnClickListener() {
            @SensorsDataInstrumented
            public void onClick(View view) {
                IntentUtils.intentToHelpCenter(BindingPhoneNumActivity.this.mContext);
                if (BindingPhoneNumActivity.this.from == 2) {
                    XrsBury.clickBury(BindingPhoneNumActivity.this.getResources().getString(R.string.mefusion_click_05_02_016));
                } else if (BindingPhoneNumActivity.this.from == 1) {
                    XrsBury.clickBury(BindingPhoneNumActivity.this.getResources().getString(R.string.fusionlogin_click_01_13_004));
                }
                SensorsDataAutoTrackHelper.trackViewOnClick(view);
            }
        });
        if (1 == this.from) {
            this.tvBindingPhoneText.setVisibility(8);
            this.ltbTitle.showLoginTitle();
            this.ltbTitle.invisibleTitle();
            findViewById.setVisibility(8);
        } else {
            this.tvBindingPhoneText.setVisibility(0);
            this.ltbTitle.hideLoginTitle();
            this.ltbTitle.visibleTitle();
            findViewById.setVisibility(0);
            if (2 == this.from) {
                this.ltbTitle.setCenterTitle("绑定新手机");
                this.tvBindingPhoneText.setVisibility(8);
            } else if (3 == this.from) {
                this.ltbTitle.setCenterTitle("绑定手机");
                this.tvBindingPhoneText.setVisibility(8);
            } else if (4 == this.from) {
                this.ltbTitle.setCenterTitle("修改密码");
                this.tvBindingPhoneText.setText("为保证帐户安全，需要短信验证");
            }
        }
        if (this.isLastPage) {
            this.ltvBtn.setText(!TextUtils.isEmpty(this.mShowInfo) ? this.mShowInfo : "完成");
        } else if (1 == this.from) {
            this.ltvBtn.setText("下一步");
        } else {
            this.ltvBtn.setText("完成");
        }
        if (AppConfig.DEBUG) {
            View findViewById2 = findViewById(R.id.test_next);
            findViewById2.setVisibility(0);
            findViewById2.setOnClickListener(new View.OnClickListener() {
                @SensorsDataInstrumented
                public void onClick(View view) {
                    LoginProcessController.getInstance().next();
                    BindingPhoneNumActivity.this.finish();
                    SensorsDataAutoTrackHelper.trackViewOnClick(view);
                }
            });
        }
    }

    private void setBtnEnable() {
        if (!this.verifyCode || !this.phoneIsValid) {
            this.ltvBtn.setEnabled(false);
        } else {
            this.ltvBtn.setEnabled(true);
        }
    }

    @SensorsDataInstrumented
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.tv_binding_phone_num_btn) {
            if (this.dataLoadEntity != null) {
                postDataLoadEvent(this.dataLoadEntity.beginLoading());
            }
            if (1 == this.from || 3 == this.from || 4 == this.from) {
                setPhone();
            } else if (2 == this.from) {
                getAccountDataInfo(this.phoneInputEdit.getPhoneNumber(), this.phoneInputEdit.getPhonePrefix());
            }
        } else if (id == R.id.tv_get_authcode) {
            if (this.from == 2) {
                XrsBury.clickBury(getResources().getString(R.string.mefusion_click_05_02_015));
            }
            TalAccApiMethods.sendSmsCodeForCheck(this.phoneInputEdit.getPhonePrefix(), this.phoneInputEdit.getPhoneNumber(), "7", new RespTagCallback() {
                public void onSuccess(String str) {
                    BindingPhoneNumActivity.this.authCodeLayout.startCountDow();
                    XrsBury.clickBury(BindingPhoneNumActivity.this.getResources().getString(R.string.fusionlogin_click_01_13_002), "1", "");
                }

                public void onError(String str) {
                    BindingPhoneNumActivity.super.onError(str);
                    XrsBury.clickBury(BindingPhoneNumActivity.this.getResources().getString(R.string.fusionlogin_click_01_13_002), "0", str);
                }
            });
        }
        SensorsDataAutoTrackHelper.trackViewOnClick(view);
    }

    /* access modifiers changed from: protected */
    public void setPhone() {
        if (!TextUtils.isEmpty(this.phoneInputEdit.getPhonePrefix()) && !TextUtils.isEmpty(this.phoneInputEdit.getPhoneNumber())) {
            this.talAccRequestApi.setPhone(new TalAccReq.SetPhoneReq(this.phoneInputEdit.getPhonePrefix(), this.phoneInputEdit.getPhoneNumber(), this.authCodeLayout.getAuthCode()), new TalAccApiCallBack<TalAccResp.CheckPhoneResp>() {
                /* JADX WARNING: type inference failed for: r0v10, types: [com.xueersi.parentsmeeting.module.fusionlogin.activity.BindingPhoneNumActivity, android.app.Activity] */
                public void onSuccess(TalAccResp.CheckPhoneResp checkPhoneResp) {
                    if (BindingPhoneNumActivity.this.phoneInputEdit != null && !TextUtils.isEmpty(BindingPhoneNumActivity.this.phoneInputEdit.getPhoneNumber())) {
                        UserInfoEdit.edit(UserBll.getInstance().getMyUserInfoEntity()).setMobile(BindingPhoneNumActivity.this.phoneInputEdit.getPhoneNumber()).commit();
                    }
                    if (BindingPhoneNumActivity.this.dataLoadEntity != null) {
                        BaseActivity.postDataLoadEvent(BindingPhoneNumActivity.this.dataLoadEntity.webDataSuccess());
                    }
                    XrsBury.clickBury(BindingPhoneNumActivity.this.getResources().getString(R.string.fusionlogin_click_01_13_003), "1");
                    if (3 == BindingPhoneNumActivity.this.from) {
                        BindingPhoneNumActivity.this.finish();
                    } else if (BindingPhoneNumActivity.this.from == 4) {
                        ResetPwdActivity.openResetPwdActivityForResult(BindingPhoneNumActivity.this, BindingPhoneNumActivity.this.phoneInputEdit.getPhonePrefix(), BindingPhoneNumActivity.this.phoneInputEdit.getPhoneNumber(), checkPhoneResp == null ? "" : checkPhoneResp.tag, 8);
                    } else if (1 == BindingPhoneNumActivity.this.from) {
                        LoginProcessController.getInstance().next();
                        BindingPhoneNumActivity.this.finish();
                    }
                }

                public void onError(TalAccErrorMsg talAccErrorMsg) {
                    BindingPhoneNumActivity.super.onError(talAccErrorMsg);
                    BindingPhoneNumActivity.this.showFailedToast(talAccErrorMsg, new String[0]);
                    if (BindingPhoneNumActivity.this.dataLoadEntity != null) {
                        BaseActivity.postDataLoadEvent(BindingPhoneNumActivity.this.dataLoadEntity.webDataSuccess());
                    }
                    XrsBury.clickBury(BindingPhoneNumActivity.this.getResources().getString(R.string.fusionlogin_click_01_13_003), "0");
                }
            });
        }
    }

    private void getAccountDataInfo(String str, String str2) {
        if (!TextUtils.isEmpty(str) && !TextUtils.isEmpty(str2)) {
            LoginProcessBll.getAccountSharedData("3", str, str2, new LoginProcessCallback<LoginAccountShareEntity, String>() {
                public void onSuccess(LoginAccountShareEntity loginAccountShareEntity) {
                    if (BindingPhoneNumActivity.this.dataLoadEntity != null) {
                        BaseActivity.postDataLoadEvent(BindingPhoneNumActivity.this.dataLoadEntity.webDataSuccess());
                    }
                    if (loginAccountShareEntity.shouldRemind != 0) {
                        final SharedAccountDialog sharedAccountDialog = new SharedAccountDialog(BindingPhoneNumActivity.this.mContext, BindingPhoneNumActivity.this.getApplication(), false, 1);
                        sharedAccountDialog.setBtnText(BindingPhoneNumActivity.this.getString(R.string.text_change_all));
                        sharedAccountDialog.setDataEntity(loginAccountShareEntity).setBtnClickListeners(new SharedAccountDialog.OnButtonClickListener() {
                            public void onLeftClick(View view) {
                                sharedAccountDialog.cancelDialog();
                            }

                            public void onRightClick(View view) {
                                sharedAccountDialog.cancelDialog();
                                BindingPhoneNumActivity.this.changePhone();
                            }
                        }).showDialog();
                        return;
                    }
                    BindingPhoneNumActivity.this.changePhone();
                }

                public void onFailure(String str) {
                    if (BindingPhoneNumActivity.this.dataLoadEntity != null) {
                        BaseActivity.postDataLoadEvent(BindingPhoneNumActivity.this.dataLoadEntity.webDataSuccess());
                    }
                    BindingPhoneNumActivity.this.toFinish();
                }
            });
        }
    }

    /* access modifiers changed from: private */
    public void toFinish() {
        setResult(LoginRegistersConfig.FUSION_REQUEST_CODE, new Intent());
        finish();
    }

    /* access modifiers changed from: private */
    public void changePhone() {
        if (!TextUtils.isEmpty(this.phoneInputEdit.getPhonePrefix()) && !TextUtils.isEmpty(this.phoneInputEdit.getPhoneNumber())) {
            XrsBury.clickBury(getResources().getString(R.string.mefusion_click_05_02_017));
            TalAccReq.ChangePhoneReq changePhoneReq = new TalAccReq.ChangePhoneReq();
            changePhoneReq.code = this.authCodeLayout.getAuthCode();
            String phoneNumber = this.phoneInputEdit.getPhoneNumber();
            String phonePrefix = this.phoneInputEdit.getPhonePrefix();
            changePhoneReq.phone = phoneNumber;
            changePhoneReq.phoneCode = phonePrefix;
            changePhoneReq.tag = this.oldTag;
            this.talAccRequestApi.changePhone(changePhoneReq, new TalAccApiCallBack<TalAccResp.StringResp>() {
                public void onSuccess(TalAccResp.StringResp stringResp) {
                    if (stringResp != null && !TextUtils.isEmpty(stringResp.result)) {
                        XESToastUtils.showToast(BindingPhoneNumActivity.this.mContext, stringResp.result);
                    }
                    if (BindingPhoneNumActivity.this.phoneInputEdit != null && !TextUtils.isEmpty(BindingPhoneNumActivity.this.phoneInputEdit.getPhoneNumber())) {
                        UserInfoEdit.edit(UserBll.getInstance().getMyUserInfoEntity()).setMobile(BindingPhoneNumActivity.this.phoneInputEdit.getPhoneNumber()).commit();
                    }
                    if (BindingPhoneNumActivity.this.dataLoadEntity != null) {
                        BaseActivity.postDataLoadEvent(BindingPhoneNumActivity.this.dataLoadEntity.webDataSuccess());
                    }
                    BindingPhoneNumActivity.this.toFinish();
                }

                public void onError(TalAccErrorMsg talAccErrorMsg) {
                    BindingPhoneNumActivity.super.onError(talAccErrorMsg);
                    BindingPhoneNumActivity.this.showFailedToast(talAccErrorMsg, new String[0]);
                    if (BindingPhoneNumActivity.this.dataLoadEntity != null) {
                        BaseActivity.postDataLoadEvent(BindingPhoneNumActivity.this.dataLoadEntity.webDataSuccess());
                    }
                }
            });
        }
    }

    public void onInputCodeChange(boolean z) {
        this.verifyCode = z;
        setBtnEnable();
    }

    public void onValid(boolean z) {
        this.phoneIsValid = z;
        if (z) {
            this.authCodeLayout.enableAuthCodeView();
        } else {
            this.authCodeLayout.disAbleAuthCodeView();
        }
        String phoneNumber = this.phoneInputEdit.getPhoneNumber();
        if (phoneNumber != null && phoneNumber.length() == 1) {
            XrsBury.clickBury(getResources().getString(R.string.fusionlogin_click_01_13_001));
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 4 && 1 == this.from) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }
}
