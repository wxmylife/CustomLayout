package com.xueersi.parentsmeeting.module.fusionlogin.widget;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.sensorsdata.analytics.android.sdk.SensorsDataAutoTrackHelper;
import com.sensorsdata.analytics.android.sdk.SensorsDataInstrumented;
import com.xueersi.parentsmeeting.module.fusionlogin.R;

public class AuthCodeLayout extends FrameLayout implements View.OnClickListener {
    private static final int AUTHCODE_LEN = 6;
    private static final int TIMEDURATION = 60;
    /* access modifiers changed from: private */
    public boolean editHasFocus;
    private EditText etAuthCode;
    private ImageView ivClear;
    /* access modifiers changed from: private */
    public EtFocusChangeCallback mEtFocusChange;
    /* access modifiers changed from: private */
    public AuthCodeViewStateListener mListener;
    private TimeCountDownTextView timeCountDowTextView;

    public interface AuthCodeViewStateListener {
        void onClick(View view);

        void onInputCodeChange(boolean z);
    }

    public interface EtFocusChangeCallback {
        void onFocusChange(boolean z);
    }

    public AuthCodeLayout(@NonNull Context context) {
        super(context, (AttributeSet) null);
        this.editHasFocus = false;
    }

    public AuthCodeLayout(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AuthCodeLayout(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.editHasFocus = false;
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.layout_authcode, this);
        this.etAuthCode = (EditText) findViewById(R.id.et_authcode);
        this.etAuthCode.setClickable(false);
        this.timeCountDowTextView = (TimeCountDownTextView) findViewById(R.id.tv_get_authcode);
        this.timeCountDowTextView.setTimeDuration(60);
        this.timeCountDowTextView.setOnClickListener(this);
        this.timeCountDowTextView.setClickable(false);
        this.ivClear = (ImageView) findViewById(R.id.iv_authcode_clear);
        this.ivClear.setOnClickListener(this);
        this.etAuthCode.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View view, boolean z) {
                if (AuthCodeLayout.this.mEtFocusChange != null) {
                    AuthCodeLayout.this.mEtFocusChange.onFocusChange(z);
                }
                boolean unused = AuthCodeLayout.this.editHasFocus = z;
                AuthCodeLayout.this.showHideIvClear();
            }
        });
        this.etAuthCode.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (AuthCodeLayout.this.mListener != null) {
                    AuthCodeLayout.this.mListener.onInputCodeChange(!TextUtils.isEmpty(charSequence) && charSequence.length() == 6);
                }
                AuthCodeLayout.this.showHideIvClear();
            }
        });
        showHideIvClear();
    }

    public void showHideIvClear() {
        if (this.etAuthCode.getText().length() == 0 || !this.editHasFocus) {
            this.ivClear.setVisibility(8);
        } else {
            this.ivClear.setVisibility(0);
        }
    }

    public void setEtFocusChangeCallback(EtFocusChangeCallback etFocusChangeCallback) {
        this.mEtFocusChange = etFocusChangeCallback;
    }

    public void setAuthCodeViewListener(AuthCodeViewStateListener authCodeViewStateListener) {
        this.mListener = authCodeViewStateListener;
    }

    @SensorsDataInstrumented
    public void onClick(View view) {
        if (view.getId() == R.id.tv_get_authcode) {
            requestInputFocuse();
            if (this.mListener != null) {
                this.mListener.onClick(view);
            }
        } else if (R.id.iv_authcode_clear == view.getId()) {
            clearAuthCode();
        }
        SensorsDataAutoTrackHelper.trackViewOnClick(view);
    }

    public void startCountDow() {
        this.timeCountDowTextView.startCountDow();
    }

    public void requestInputFocuse() {
        this.etAuthCode.requestFocus();
        this.etAuthCode.setSelection(this.etAuthCode.getText().toString().length());
    }

    public void enableAuthCodeView() {
        if (!this.timeCountDowTextView.isOnCountDowning()) {
            this.timeCountDowTextView.setClickable(true);
            this.timeCountDowTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.COLOR_212832));
        }
        this.etAuthCode.setSelection(this.etAuthCode.getText().length());
    }

    public void showSoftInput() {
        this.etAuthCode.setFocusable(true);
        this.etAuthCode.setFocusableInTouchMode(true);
        this.etAuthCode.requestFocus();
        ((InputMethodManager) this.etAuthCode.getContext().getSystemService("input_method")).toggleSoftInput(0, 2);
    }

    public void disAbleAuthCodeView() {
        this.timeCountDowTextView.setClickable(false);
        this.timeCountDowTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.COLOR_ADB4BE));
    }

    public String getAuthCode() {
        return this.etAuthCode.getText().toString();
    }

    private void clearAuthCode() {
        this.etAuthCode.setText("");
        this.ivClear.setVisibility(8);
    }
}
